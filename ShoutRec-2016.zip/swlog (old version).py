#   Count the shouts in the file by counting the lines in it
def shout_count():
    try:
        log = open('swlog.txt')
    except:
        print "<Error Opening File>"
        return -1

    shouts = 0
    for line in log:
        shouts += 1

    log.close()
    return count

#   Initialize
print "Shout Wall Utility (Python 2.7)"

# Declare global variables
count = shout_count()
ShoutQuota = 250

if count != -1 :
    print "\tCurrent shouts:", count
    print "\tCurrent quota: ", ShoutQuota

#   Create a new Shout Wall log if there is none at the start of the new week
if count == -1:
    open_log = raw_input("Create New Log File? (Y/N) ")
    if open_log == 'Y':
        open_log = 'y'
    if open_log == 'y':
        swout = open('swlog.txt', 'w')
        count = 0
    if open_log == 'N':
        open_log = 'n'
    if open_log == 'n':
        print "<New File Cancelled - Closing Program>"
else:
    open_log = 'none'

    
#   Start main body of program
while open_log != 'n' :
    cmd = raw_input("main > ")
    if cmd == '.done' :
        break
    elif cmd == '.shouts' :
        count = shout_count()
        print '\tShouts:', count

#   Print help menu
    elif cmd == ".help":
        print "---- COMMANDS --------------------------------"
        print "\t.shouts\tDisplays # of shouts"
        print "\t.help\tHelp Menu"
        print "\t.done\tQuit Program"
        print "----------------------------------------------"

#   Log shouts to file 'swlog.txt'
    elif cmd == '.log' :
        swout = open('swlog.txt', 'a')
        while True:
            log = raw_input("log\t > ")
            if log == ".done" :
                swout.close()
                break
            elif log == '.shouts' :
                print "\tShouts: ", count
            else:
                count = int(count) + 1
                swout.write(str(count) + ":\t" + log + "\n")

#   Calculate & print statistics
    elif cmd == '.stats' :
        weekday = int(raw_input("\tWeekday Number (Sun = 0): "))
        # TODO: Add a weekday confirmation (Using lists?)

        #   Refresh the shout count
        count = shout_count()

        average_shouts = count / (weekday + 1)
        shouts_left = 250 - count

        #   Calculate the statistic values
        #   Calculate earnings with $50.00 earning limit
        if count > 250 :
            earnings = 50.00
        else :
            earnings = count * 0.20
            # TODO: Round to 2 decimal places

        #   Print the statistic values
        print "\tEarnings:\t\t$", earnings
        print "\tAverage Shouts Per Day:\t", average_shouts
        print "\tShouts Left to Quota:\t", shouts_left

    # To finalize the log, write the invoice to file as a kind of footer
    elif cmd == '.fin' :
        earnings = count * 0.20
        swout = open('swlog.txt', 'a')
        swout.write("==== FINAL INVOICE ==================================================\n")
        swout.write("Paypal email:\t\t\tBelgarion270@gmail.com\n")
        swout.write("Shouts Completed:\t" + str(count))
        swout.write("\nPaypal Amount:\t\t\t$" + str(earnings) + "0")
        swout.write("\n================================================================\n")
        swout.close()
        # Print out to the screen as a confirmation
        print "==== FINAL INVOICE ============================================"
        print "Paypal email:\t\tBelgarion270@gmail.com"
        print "Shouts Completed:\t" + str(count)
        print "Paypal Amount:\t\t$" + str(earnings) + "0"
        print "================================================================"

    # In the case of a strange week or other change, resets the shout quota
    elif cmd == '.setShoutQuota' :
        ShoutQuota = int(raw_input("\tSet the new shout quota: "))
        
#   If unknown command is entered, then print error message
    else:
        print "<Command Not Recognized>"
